import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-conversation',
  templateUrl: './conversation.component.html',
  styleUrls: ['./conversation.component.css']
})
export class ConversationComponent implements OnInit {

  isAuthenticated: boolean = false;

  arrDummyConversation = [];
  messageDialogModel: any = {};

  messageDialogByUser: string = "";

  constructor() { }

  ngOnInit() {
    this.arrDummyConversation.push(
      { type: "r", text: "hii..." },
      { type: "s", text: "welcome to mahindra and mahindra" },
      { type: "r", text: "how are you" },
      { type: "s", text: "hypothetical question..." },
      { type: "s", text: "is their any problem which hampers your productivity sir" },
      { type: "r", text: "thank you for your concern..." },

    );
  }

  onLogin() {
    this.isAuthenticated = !this.isAuthenticated;
    console.log("captured in parent component", this.isAuthenticated);
  }
  ifiufi
  sendMessage() {
    console.log(this.messageDialogModel.dialog);
    this.arrDummyConversation.push({ type: 'r', text: this.messageDialogModel.dialog });
  }



}
